Synthetic README.
